@echo off
title NEBULA CORE v2.0 - WINDOWS LAUNCHER
cd /d "%~dp0"
if exist "NebulaCore_Offline_v2_V16.html" (
  start "" "NebulaCore_Offline_v2_V16.html"
) else (
  start "" "public\NebulaCore_Offline.html"
)
exit

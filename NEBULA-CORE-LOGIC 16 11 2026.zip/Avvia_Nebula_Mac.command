#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 1
HTML_FILE="NebulaCore_Offline_v2_V16.html"
[ ! -f "$HTML_FILE" ] && HTML_FILE="public/NebulaCore_Offline.html"
if [ ! -f "$HTML_FILE" ]; then
  echo "File HTML non trovato in $DIR"
  exit 1
fi
echo "Avvio Nebula Core v2.0..."
if command -v python3 >/dev/null 2>&1; then
  PORT=$(python3 -c "import socket; s=socket.socket(); s.bind(('127.0.0.1',0)); print(s.getsockname()[1]); s.close()")
  python3 -m http.server "$PORT" --bind 127.0.0.1 >/dev/null 2>&1 &
  PID=$!
  trap 'kill "$PID" 2>/dev/null' EXIT INT TERM
  for i in 1 2 3 4 5 6 7 8 9 10; do
    if python3 -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:$PORT/$HTML_FILE', timeout=0.4)" >/dev/null 2>&1; then
      break
    fi
    sleep 0.2
  done
  open "http://127.0.0.1:$PORT/$HTML_FILE" || open "$DIR/$HTML_FILE"
  echo "Nebula Core avviato! Premi CTRL+C per arrestare il server."
  wait "$PID" 2>/dev/null
else
  open "$DIR/$HTML_FILE"
fi
